sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("userinfo.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);